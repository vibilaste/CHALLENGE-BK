# Ticketing App

A modern event ticketing system built with Laravel 12 and Tailwind CSS, featuring event management, ticket booking, and order processing capabilities.

## Prerequisites

Before you begin, ensure you have the following installed on your system:

### Required Software

1. **PHP >= 8.2** (minimum version: **8.2.0**)
    - Check version: `php -v`
    - Download: [https://www.php.net/downloads](https://www.php.net/downloads)
    - For macOS: `brew install php@8.2`

2. **Composer >= 2.5** (minimum version: **2.5.0**)
    - Check version: `composer -V`
    - Download: [https://getcomposer.org/download/](https://getcomposer.org/download/)
    - For macOS: `brew install composer`

3. **Node.js >= 18.0** and **npm >= 9.0** (minimum versions: **Node 18.0.0**, **npm 9.0.0**)
    - Check versions: `node -v` and `npm -v`
    - Download: [https://nodejs.org/](https://nodejs.org/)
    - For macOS: `brew install node`

4. **MySQL >= 8.0** (Database)
    - Check version: `mysql --version`
    - Download: [https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/)
    - For macOS: `brew install mysql`

### PHP Extensions

Ensure the following PHP extensions are enabled:

- `php-mysql` (for MySQL database)
- `php-mbstring`
- `php-xml`
- `php-curl`
- `php-zip`
- `php-bcmath`
- `php-fileinfo`
- `php-tokenizer`

> [!TIP]
> You can check your PHP configuration by running `php -m` to see all loaded extensions.

---

## Installation & Initialization

### Step 1: Extract the Project

Extract the compressed folder and navigate to the project directory:

```bash
cd ticketing-app
```

### Step 2: Install PHP Dependencies

Install all Composer packages required by the Laravel application:

```bash
composer install
```

> [!NOTE]
> This will install Laravel 12, Laravel Breeze, and other PHP dependencies defined in `composer.json`.

### Step 3: Install JavaScript Dependencies

Install all npm packages for frontend assets:

```bash
npm install
```

> [!NOTE]
> This installs Vite, Tailwind CSS, Alpine.js, and other frontend dependencies.

### Step 4: Environment Configuration

Create your environment configuration file:

> [!NOTE] Copy existing .env.example file and rename to .env

```bash
cp .env.example .env
```

Then update the `.env` file with your MySQL database credentials:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ticketing_app
DB_USERNAME=your_mysql_username
DB_PASSWORD=your_mysql_password
```

> [!IMPORTANT]
> The `.env` file contains sensitive configuration. Never share this file publicly.

### Step 5: Generate Application Key

Generate a unique application encryption key:

```bash
php artisan key:generate
```

This command will automatically update the `APP_KEY` value in your `.env` file.

### Step 6: Create Database

Create a new MySQL database for the application:

**Option 1: Using MySQL Command Line:**

```bash
mysql -u your_mysql_username -p
```

Then in the MySQL prompt:

```sql
CREATE DATABASE ticketing_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

**Option 2: Using XAMPP (phpMyAdmin):**

1. Start XAMPP and ensure MySQL/Apache is running
2. Open your browser and go to [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
3. Click on "New" in the left sidebar or click the "Databases" tab
4. Enter database name: `ticketing_app`
5. Select collation: `utf8mb4_unicode_ci` from the dropdown
6. Click "Create" button

**Option 3: Using Laragon:**

1. Start Laragon and ensure MySQL is running (click "Start All")
2. Right-click on Laragon tray icon → MySQL → Open phpMyAdmin
3. Or access directly at [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
4. Click "New" in the left sidebar or click the "Databases" tab
5. Enter database name: `ticketing_app`
6. Select collation: `utf8mb4_unicode_ci` from the dropdown
7. Click "Create" button

**Option 4: Using DBeaver:**

1. Open DBeaver and connect to your MySQL server
2. Right-click on your MySQL connection in the Database Navigator
3. Select "Create" → "Database"
4. Enter database name: `ticketing_app`
5. In the "General" tab, set:
    - Charset: `utf8mb4`
    - Collation: `utf8mb4_unicode_ci`
6. Click "OK" to create the database

> [!NOTE]
> Make sure the database name matches the `DB_DATABASE` value in your `.env` file.

### Step 7: Run Database Migrations

Create all necessary database tables:

```bash
php artisan migrate
```

This will create tables for:

- Users
- Events
- Categories
- Tickets
- Orders
- Sessions
- Password resets
- And other system tables

### Step 8: Seed Database

Populate the database with sample data:

```bash
php artisan db:seed
```

This will create:

- Sample users (including admin accounts)
- Event categories
- Sample events
- Tickets
- Orders

> [!TIP]
> You can skip this step if you want to start with an empty database.

### Step 9: Build Frontend Assets

Compile the frontend assets for production:

```bash
npm run build
```

Or for development with hot reloading:

```bash
npm run dev
```

---

## Quick Setup (Alternative)

You can run most of the installation steps at once using the custom composer script:

```bash
composer setup
```

This single command will:

1. Install Composer dependencies
2. Copy `.env.example` to `.env`
3. Generate application key
4. Run migrations
5. Install npm dependencies
6. Build frontend assets

> [!WARNING]
> You still need to:
>
> 1. Manually configure your MySQL database credentials in the `.env` file
> 2. Create the MySQL database before running migrations

---

## Running the Application

### Development Mode

For local development with all necessary services:

```bash
composer dev
```

This will start:

- **Laravel development server** (http://localhost:8000)
- **Queue worker** for background jobs
- **Log viewer** (Laravel Pail)
- **Vite dev server** for hot module replacement

## Default Credentials

If you ran the database seeder, you can log in with:

> [!CAUTION]
> Change these credentials immediately in production environments!

Check the `database/seeders/UserSeeder.php` file for the default user credentials.

---

## Project Structure

```
├── app/                  # Application core (Models, Controllers, etc.)
├── bootstrap/            # Framework bootstrap files
├── config/              # Configuration files
├── database/            # Migrations, factories, and seeders
├── public/              # Public assets (entry point)
├── resources/           # Views, CSS, JS source files
├── routes/              # Application routes
├── storage/             # Logs, cache, uploaded files
├── tests/               # Test files
└── vendor/              # Composer dependencies
```

---

## Technologies Used

- **Backend:** Laravel 12 (PHP 8.2)
- **Authentication:** Laravel Breeze
- **Frontend:** Tailwind CSS v3, Alpine.js
- **Build Tool:** Vite
- **Database:** MySQL
- **Queue:** Database driver

---

## Troubleshooting

### Clear Cache

If configuration changes aren't reflected:

```bash
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan route:clear
```

### Optimize Files

If newly added route or function isn't detected

```bash
php artisan optimize
```

or (if error)

```bash
php artisan optimize:clear
```

> [!NOTE] The 'optimize' command will also run Clear Cache Commands

### Database Issues

If migrations fail, you can reset the database:

```bash
php artisan migrate:fresh --seed
```

> [!CAUTION]
> This will drop all tables and re-run migrations. All data will be lost!

---

## Next Steps

1. Configure your mail settings in `.env` for email notifications
2. Update `APP_NAME` and `APP_URL` in `.env`
3. Review and customize authentication views in `resources/views/auth/`
4. Explore the application structure and begin development
